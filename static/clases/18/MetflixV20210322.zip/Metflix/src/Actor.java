public class Actor extends Persona {
    
}
