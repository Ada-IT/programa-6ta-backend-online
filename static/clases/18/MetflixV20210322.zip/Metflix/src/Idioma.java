public class Idioma {
    public String nombre;
    public String alfabeto;
}
