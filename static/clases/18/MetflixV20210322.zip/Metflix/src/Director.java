public class Director extends Persona {
    
}
