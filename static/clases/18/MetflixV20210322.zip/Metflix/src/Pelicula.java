public class Pelicula extends Contenido {
    public int duracion; //en minutos
    public Director director;
    public boolean filmadaEnIMAX;
}
