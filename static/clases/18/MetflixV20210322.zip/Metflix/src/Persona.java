public class Persona {
    public String nombre;
}
