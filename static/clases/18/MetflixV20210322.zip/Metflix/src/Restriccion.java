public class Restriccion {
    
}
