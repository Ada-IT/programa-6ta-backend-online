import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Ingrese Año: ");
        int año;

        Scanner Entrada = new Scanner(System.in);
        año = Entrada.nextInt();

        System.out.println("Ingrese Mes: ");
        int mes;
        mes = Entrada.nextInt();

        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                System.out.println("Este mes tiene 31 dias");
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                System.out.println("Este mes tiene 30 dias.");
                break;
            case 2:
                if (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0)) {
                    System.out.println("Este mes tiene 29 dias.");
                } else {
                    System.out.println("Este mes tiene 28 dias");

                }
                break;
            default:
                System.out.println("No es un mes valido");
        }

    }
}