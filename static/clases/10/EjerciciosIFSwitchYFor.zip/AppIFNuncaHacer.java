
import java.util.Scanner;

public class AppNuncaHacer {
    public static void main(String[] args) throws Exception {
        System.out.println("Ingrese año: ");
        int año;
        Scanner Entrada = new Scanner(System.in);
        año = Entrada.nextInt();
        System.out.println("Ingrese mes: ");
        int mes;
        mes = Entrada.nextInt();
        //Tienen 31 días: Enero, marzo, mayo, julio, agosto, octubre y diciembre. 
        //Tienen 30 días: Abril, junio, septiembre y noviembre.

        if (mes == 2) {

            if (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0)) {

                System.out.println("Tiene 19 dias.");

            } else {
                System.out.println("Tiene 28 dias");
            }
        } else {
            if (mes == 1) {
                System.out.println("el mes tiene 31 dias");
            } else {
                if (mes == 3) {
                    System.out.println("el mes tiene 31 dias");
                } else {
                    if (mes == 4) {
                        System.out.println("el mes tiene 30 dias");
                    } else {
                        if (mes == 5) {
                            System.out.println("el mes tiene 31 dias");
                        } else {
                            if (mes == 6) {
                                System.out.println("el mes tiene 30 dias");
                            } else {
                                if (mes == 7) {
                                    System.out.println("el mes tiene 31 dias");
                                } else {
                                    if (mes == 8) {
                                        System.out.println("el mes tiene 31 dias");
                                    } else {
                                        if (mes == 9) {
                                            System.out.println("el mes tiene 30 dias");
                                        } else {
                                            if (mes == 10) {
                                                System.out.println("el mes tiene 31 dias");
                                            } else {
                                                if (mes == 11) {
                                                    System.out.println("el mes tiene 30 dias");
                                                } else {
                                                    System.out.println("el mes tiene 31 dias");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}
