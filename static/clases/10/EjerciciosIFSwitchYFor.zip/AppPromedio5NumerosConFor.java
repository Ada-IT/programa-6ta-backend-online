import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        Scanner Entrada = new Scanner(System.in);

        //Declaro y asigno directamente la variable.
        //La declaracion de abajo es igual a:
        //int suma;
        //suma = 0,
        int suma = 0;
        
        int cantNumeroAIngresar = 5;
        //FOR de 1 a 5 -> 5 vueltas
        // la primer parte: declara y asigna la variable i en 1 el comienzo
        // la segunda partes: es una condicion de corte, o sea, dar tantas vueltas
        // hasta que esa condicion sea FALSO(false)
        // la tercer parte: sera como incremento i en cada vuelta, en este caso i++
        // i++ es igual a i = i + 1
        for(int i = 1 ; i <= cantNumeroAIngresar; i++){
            System.out.println("Ingrese un numero");
            
            int n;
            
            n = Entrada.nextInt();

            suma = suma + n;

        }

        //Si empiezo a ejecutar por esta linea, quiere decir
        //que el ciclo de arriba termino.
        // en este caso termina porque i fue mayor a 5
        double promedio;
        promedio = suma / (cantNumeroAIngresar * 1.0);

        System.out.println("El promedio es " + promedio);

        
    }
}