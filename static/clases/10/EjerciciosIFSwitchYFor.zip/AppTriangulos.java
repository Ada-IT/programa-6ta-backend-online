import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        int l1;
        int l2;
        int l3;
        
        System.out.println("Ingrese L1");
        Scanner Entrada = new Scanner(System.in);
        l1 = Entrada.nextInt();

        System.out.println("Ingrese L2");
        l2 = Entrada.nextInt();

        System.out.println("Ingrese L3");
        l3 = Entrada.nextInt();

        if (l1 == l2 && l1 == l3 && l2 == l3){
            System.out.println("Equilatero");
        }
        else {
            if(l1 == l2 || l2 == l3 || l1 == l3){
                System.out.println("Isosceles");
            } 
            else {
                System.out.println("Escaleno");
            }

        }

    
    }
}