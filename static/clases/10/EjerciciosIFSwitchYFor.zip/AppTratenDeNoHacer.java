
import java.util.Scanner;

public class AppVTratenDeNoHacer {
    public static void main(String[] args) throws Exception {
        System.out.println("Ingrese AÑO: ");
        int año;
        Scanner Entrada = new Scanner(System.in);
        año = Entrada.nextInt();
        System.out.println("Ingrese numero de MES: ");
        int mes;
        mes = Entrada.nextInt();
        if (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0)) {
            if (mes == 1 || 
                mes == 3 || 
                mes == 5 || 
                mes == 7 || 
                mes == 8 || 
                mes == 10 ||
                mes == 12) {
                System.out.println("Este mes tiene 31 dias.");
            } else {
                if (mes == 2) {
                    System.out.println("Este mes tiene 29 dias.");
                } else {
                    System.out.println("Este mes tiene 30 dias");
                }
            }
        } else {
            if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
                System.out.println("Este mes tiene 31 dias.");
            } else {
                if (mes == 2) {
                    System.out.println("Este mes tiene 28 dias.");
                } else {
                    System.out.println("Este mes tiene 30 dias");
                }
            }
        }

    }
}
