import java.util.Date;

 public class Paciente {
    //atributos/caracteristiccas
    public String nombre;
    public Date fechaNacimiento;
    public String especie;
    public Cliente dueño;
}
