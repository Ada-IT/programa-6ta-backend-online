import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        //Ciclo WHILE: es un ciclo, que ejecuta un cierto bloque de codigo
        //Mientras ocurra alguna condicion especifica.
        /*
                Ej. MI-15: Ingresar e informar valores, 
                mientras que el valor ingresado no sea negativo. 
                Informar la cantidad de valores ingresados.

        */
        /* ciclo while se escribe asi:
           while (condicion) {
               //bloque de codigo
           }
        */

        Scanner Teclado = new Scanner(System.in);
        int numero;
        int cantidad = 0;

        //Esto ocurre una sola vez
        System.out.println("Ingrese un numero: ");
        numero = Teclado.nextInt();

        //Cuando haya una cantidad de operaciones INDEFINIDAS
        //While de Repetion INDEFINIDA de 0 a N
        while (numero >= 0){
            //Si estoy aqui dentro con un breakpoint 
            //=> signfica que cumplio la condicion
            cantidad++; // cantidad = cantidad + 1;
            //por que no pongo un if en este caso para checkear el numero?
            //porque ya cumplio la condicion numero >= 0 , por lo tanto
            //queda redundante.
            
            //Hay que volver a ingresar el numero
            System.out.println("Ingrese un numero: ");
            numero = Teclado.nextInt();
        }
        //sabemos que al final, tenemos que imprimir la cantidad total de ingresados.
        System.out.println("Cantidad: "+ cantidad+ ".");
    }
}
