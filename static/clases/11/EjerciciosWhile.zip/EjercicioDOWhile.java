import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        //Ciclo WHILE: es un ciclo, que ejecuta un cierto bloque de codigo
        //Mientras ocurra alguna condicion especifica.
        /*
                Ej. MI-15 Version DO WHILE: Ingresar e informar valores, 
                mientras que el valor ingresado no sea negativo. 
                Informar la cantidad de valores ingresados.
                Nota: el primero es siempre positivo
        
        */
        /* ciclo do while se escribe asi:
           do {
               //bloque de codigo
           }
           while(condicion)
        */

        Scanner Teclado = new Scanner(System.in);
        int numero;
        int cantidad = 0;

        //DO WHILE en JAVA: es un ciclo INDEFINIDO de 1 a N
        // Primero hace, y despues pregunta.
        do {
            System.out.println("Ingrese un numero: ");
            numero = Teclado.nextInt();
            if (numero >= 0)
                cantidad++;
        }
        while( numero >= 0);

        System.out.println("La cantidad es "+ cantidad);
    }
}
